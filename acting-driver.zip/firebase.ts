
// This file is no longer used. The system has migrated to Supabase.
export {};
