
// This file is deprecated. See index.tsx for the vanilla implementation.
export {};
